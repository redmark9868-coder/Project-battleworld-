# Building the Android app (Capacitor)

Requires: Node 18+, Android Studio (with SDK for API 36), JDK 17+. Your server must already be deployed over HTTPS.

1. Set your server URL in `public/config.js`:
   `window.BW_SERVER_URL = "https://your-server.example.com";`
2. Install Capacitor (Capacitor 8+ targets API 36, which Google Play currently requires):
   ```
   npm install
   npm install @capacitor/core @capacitor/android
   npm install -D @capacitor/cli
   ```
3. Edit `capacitor.config.json`: set a unique `appId` (e.g. `com.yourname.battleworld`) and `appName`.
4. `npm run build:www` then `npx cap add android` then `npx cap sync android`
5. Lock to landscape: in `android/app/src/main/AndroidManifest.xml`, add to the `<activity>` tag:
   `android:screenOrientation="sensorLandscape"`
6. Add icons/splash (Android Studio: right-click `res` > New > Image Asset).
7. Test on a real phone: `npx cap open android`, press Run.
8. Release: Android Studio > Build > Generate Signed App Bundle (AAB). Keep your upload keystore safe and backed up.
   After changing web files, repeat `npm run build:www` and `npx cap sync android`.

## Play Console checklist
- Developer account ($25 one-time). New personal accounts need a closed test with 12+ testers for 14 continuous days before production.
- Target API 36, 16 KB page-size support (Capacitor 8 templates handle this).
- Privacy policy URL, Data safety form (you collect a display name and network identifiers), content rating questionnaire.
- Explain the in-game Report button and moderation plan; player names are user-generated content.
- Re-check current requirements at developer.android.com/google/play/requirements/target-sdk before submitting.
