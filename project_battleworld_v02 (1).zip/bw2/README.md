# Project BattleWorld v0.2

Original 2D jetpack arena shooter. Browser + Android (via Capacitor). Server-authoritative Node/Socket.IO backend.

## What's new in v0.2
- Client-side prediction with server reconciliation (your movement is instant), interpolation for other players
- Shared deterministic physics (`public/shared.js`) used by both server and client
- Solid one-way platforms on the server, a real multi-tier arena, coyote time and a mid-air jetpack boost
- Twin-stick touch controls (move / aim + auto-fire / jump button), keyboard + mouse on desktop
- Timed matches: waiting > countdown > 2:00 match > scoreboard > automatic rematch
- Public rooms are topped up with bots so a solo player always has a match
- Spawn protection, respawn at the safest spawn point, kill feed, hit sparks, screen shake, haptics, synthesized sound effects (no audio files)
- Compact snapshots (~330 bytes at 30 Hz), input rate limiting, name sanitising, in-app Report button
- Names are remembered; a `/health` endpoint for hosting uptime checks

## Run locally
1. Node.js 18+
2. `npm install`  (also copies the Socket.IO client into `public/vendor/`)
3. `npm start`, open http://localhost:3000 (open two tabs to test multiplayer)

## Deploy the server
Use any Node host that supports WebSockets (Render, Railway, Fly.io, a VPS). Build: `npm install`, start: `npm start`. Use the HTTPS URL. See `ANDROID.md` for the app.

## Known limits (next steps)
- No accounts or persistent progression yet; no profanity filter beyond character sanitising
- Hit detection uses server positions (no lag compensation); fine up to ~100 ms ping
- One weapon, one map; pickups, weapons and more maps are the natural next additions
- Single server process (rooms live in memory); scale out later with a Socket.IO adapter
- Report button only logs to the server console: connect it to real moderation before launch
- Replace all placeholder identifiers (`com.yourname.battleworld`, icons) before publishing
