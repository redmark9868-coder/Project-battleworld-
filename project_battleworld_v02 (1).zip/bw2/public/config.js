// Leave empty for the website (same server). For the Android app, set your deployed server's HTTPS URL, e.g.:
// window.BW_SERVER_URL = "https://battleworld.example.com";
window.BW_SERVER_URL = "";
