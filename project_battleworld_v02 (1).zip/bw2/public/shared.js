// Shared by server (authoritative) and client (prediction). Must stay deterministic.
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.BW = factory();
})(typeof self !== "undefined" ? self : this, function () {
  const WORLD = { width: 2200, height: 900, ground: 840 };
  // One-way platforms: you can jump up through them and land on top. y = top surface.
  const PLATFORMS = [
    { x: 60, y: 740, w: 200 }, { x: 1000, y: 740, w: 200 }, { x: 1940, y: 740, w: 200 },
    { x: 400, y: 650, w: 220 }, { x: 1580, y: 650, w: 220 },
    { x: 700, y: 560, w: 200 }, { x: 1300, y: 560, w: 200 },
    { x: 60, y: 560, w: 180 }, { x: 1960, y: 560, w: 180 },
    { x: 1000, y: 470, w: 200 },
    { x: 380, y: 450, w: 200 }, { x: 1620, y: 450, w: 200 }
  ];
  const SPAWNS = [
    { x: 160, y: 740 }, { x: 2040, y: 740 }, { x: 1100, y: 740 }, { x: 500, y: 650 },
    { x: 1700, y: 650 }, { x: 800, y: 560 }, { x: 1400, y: 560 }, { x: 1100, y: 470 }
  ];
  const TICK_RATE = 60, STEP_MS = 1000 / TICK_RATE;
  const HW = 14, ACC = 1.3, FRICTION = 0.82, MAXVX = 6.2;
  const GRAV = 0.6, JUMP = 13, MAXFALL = 16, COYOTE = 6;

  function newBody(x, y) {
    return { x, y, vx: 0, vy: 0, pj: 0, coyote: 0, air: 1 };
  }

  // cmd: { l, r, j } (0/1). Returns true if grounded after the step.
  function stepPlayer(p, c) {
    const prevY = p.y;
    if (c.l) p.vx -= ACC;
    if (c.r) p.vx += ACC;
    p.vx *= FRICTION;
    if (p.vx > MAXVX) p.vx = MAXVX; else if (p.vx < -MAXVX) p.vx = -MAXVX;
    p.x += p.vx;
    if (p.x < 20) { p.x = 20; p.vx = 0; }
    if (p.x > WORLD.width - 20) { p.x = WORLD.width - 20; p.vx = 0; }

    const jp = c.j && !p.pj;
    p.pj = c.j ? 1 : 0;
    if (jp) {
      if (p.coyote > 0) { p.vy = -JUMP; p.coyote = 0; }
      else if (p.air > 0) { p.vy = -JUMP * 0.92; p.air = 0; p.burst = 1; }
    }
    p.vy = Math.min(p.vy + GRAV, MAXFALL);
    p.y += p.vy;

    let grounded = false;
    if (p.vy >= 0) {
      if (p.y >= WORLD.ground) { p.y = WORLD.ground; p.vy = 0; grounded = true; }
      else {
        for (let i = 0; i < PLATFORMS.length; i++) {
          const pl = PLATFORMS[i];
          if (p.x + HW > pl.x && p.x - HW < pl.x + pl.w && prevY <= pl.y && p.y >= pl.y) {
            p.y = pl.y; p.vy = 0; grounded = true; break;
          }
        }
      }
    }
    if (grounded) { p.coyote = COYOTE; p.air = 1; }
    else if (p.coyote > 0) p.coyote--;
    return grounded;
  }

  return { WORLD, PLATFORMS, SPAWNS, TICK_RATE, STEP_MS, HW, stepPlayer, newBody };
});
