// "vendor": copy the Socket.IO browser client into public/vendor so the page (and the Android app) can load it locally.
// "www":    copy public/ into www/ for Capacitor.
const fs = require("fs"), path = require("path");
const root = path.join(__dirname, "..");
function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    e.isDirectory() ? copyDir(s, d) : fs.copyFileSync(s, d);
  }
}
function vendor() {
  const src = path.join(root, "node_modules", "socket.io", "client-dist", "socket.io.min.js");
  const dst = path.join(root, "public", "vendor", "socket.io.min.js");
  if (!fs.existsSync(src)) { console.warn("socket.io client not found; run npm install first."); return; }
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  console.log("Copied socket.io client to public/vendor/");
}
if (process.argv[2] === "www") { vendor(); fs.rmSync(path.join(root, "www"), { recursive: true, force: true }); copyDir(path.join(root, "public"), path.join(root, "www")); console.log("Built www/"); }
else vendor();
