const express = require("express");
const http = require("http");
const path = require("path");
const crypto = require("crypto");
const { Server } = require("socket.io");
const BW = require("./public/shared.js");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" }, pingInterval: 10000, pingTimeout: 10000 });
app.use(express.static(path.join(__dirname, "public"), { maxAge: "1h" }));
app.get("/health", (_req, res) => res.json({ ok: true, rooms: rooms.size }));

const PORT = process.env.PORT || 3000;
const { WORLD, SPAWNS, TICK_RATE, STEP_MS } = BW;
const MAX_HUMANS = 8, PUBLIC_TARGET = 4;      // public rooms are topped up with bots to this size
const MATCH_SEC = 120, COUNTDOWN_SEC = 5, RESULTS_SEC = 10;
const DMG = 20, HIT_R = 24, SHOT_COOLDOWN = 20, BULLET_SPEED = 14, BULLET_LIFE = 70;
const RESPAWN_TICKS = 150, PROTECT_TICKS = 120;
const COLORS = ["#55d6be", "#ffca58", "#ff6b6b", "#8b9dff", "#d58cff", "#8de06f", "#ff9f6e", "#67c9ff"];
const BOT_NAMES = ["Rusty", "Zippy", "Nova", "Bolt", "Pixel", "Comet", "Turbo", "Echo"];

const rooms = new Map();
let publicCounter = 0;

const r1 = v => Math.round(v * 10) / 10;
const r3 = v => Math.round(v * 1000) / 1000;
const cleanName = n => String(n || "").replace(/[^\p{L}\p{N} _.\-]/gu, "").trim().slice(0, 14) || "Pilot";
const makeCode = () => crypto.randomBytes(3).toString("hex").toUpperCase();
const humans = room => [...room.players.values()].filter(p => !p.bot);

function makeRoom(code, isPublic) {
  const room = { code, isPublic, players: new Map(), bullets: [], nextBullet: 1, nextN: 1,
    tick: 0, phase: "waiting", phaseEnd: 0 };
  rooms.set(code, room);
  return room;
}

function pickSpawn(room, self) {
  let best = SPAWNS[0], bestD = -1;
  for (const s of SPAWNS) {
    let d = 1e9;
    for (const o of room.players.values()) if (o !== self && o.hp > 0) d = Math.min(d, Math.hypot(o.x - s.x, o.y - s.y));
    d += Math.random() * 150;
    if (d > bestD) { bestD = d; best = s; }
  }
  return best;
}

function addPlayer(room, { id, name, bot }) {
  const used = new Set([...room.players.values()].map(p => p.color));
  const color = COLORS.find(c => !used.has(c)) || COLORS[room.nextN % COLORS.length];
  const s = pickSpawn(room, null);
  const p = { id, n: room.nextN++, name, bot: !!bot, color, ...BW.newBody(s.x, s.y),
    hp: 100, kills: 0, deaths: 0, a: 0, ack: 0, q: [], lastSeq: 0, lastShot: -99,
    respawnAt: 0, prot: PROTECT_TICKS, ai: { think: 0, strafe: 1, burst: true } };
  room.players.set(id, p);
  return p;
}

function sendRoster(room) {
  io.to(room.code).emit("roster", [...room.players.values()].map(p => ({ n: p.n, name: p.name, color: p.color, bot: p.bot })));
}

function balanceBots(room) {
  if (!room.isPublic) return;
  const h = humans(room).length;
  const bots = [...room.players.values()].filter(p => p.bot);
  const want = h === 0 ? 0 : Math.max(0, PUBLIC_TARGET - h);
  while (bots.length > want) room.players.delete(bots.pop().id);
  while (bots.length < want) {
    const name = BOT_NAMES[(room.nextN - 1) % BOT_NAMES.length] + " (bot)";
    bots.push(addPlayer(room, { id: "bot-" + room.nextN, name, bot: true }));
  }
  sendRoster(room);
}

function leaveRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  socket.data.roomCode = null;
  socket.leave(code);
  const room = rooms.get(code);
  if (!room) return;
  room.players.delete(socket.id);
  if (humans(room).length === 0) { rooms.delete(code); return; }
  balanceBots(room);
  sendRoster(room);
}

function joinRoom(socket, room, name) {
  if (humans(room).length >= MAX_HUMANS) return socket.emit("errorMessage", "That room is full.");
  leaveRoom(socket);
  const p = addPlayer(room, { id: socket.id, name });
  socket.join(room.code);
  socket.data.roomCode = room.code;
  socket.emit("joined", { code: room.code, isPublic: room.isPublic, n: p.n });
  balanceBots(room);
  sendRoster(room);
}

function findPublicRoom() {
  let best = null;
  for (const r of rooms.values()) {
    if (!r.isPublic) continue;
    const h = humans(r).length;
    if (h < MAX_HUMANS && (!best || h > humans(best).length)) best = r;
  }
  return best || makeRoom("PUBLIC-" + (++publicCounter), true);
}

// ---- socket handlers ----
function limited(socket, key, ms) {
  const now = Date.now(), k = "rl_" + key;
  if (socket.data[k] && now - socket.data[k] < ms) return true;
  socket.data[k] = now;
  return false;
}

io.on("connection", socket => {
  socket.on("publicJoin", name => { if (limited(socket, "join", 500)) return; joinRoom(socket, findPublicRoom(), cleanName(name)); });
  socket.on("createPrivate", name => {
    if (limited(socket, "join", 500)) return;
    let code = makeCode();
    while (rooms.has(code)) code = makeCode();
    joinRoom(socket, makeRoom(code, false), cleanName(name));
  });
  socket.on("joinPrivate", d => {
    if (limited(socket, "join", 500)) return;
    const room = rooms.get(String((d && d.code) || "").trim().toUpperCase());
    if (!room || room.isPublic) return socket.emit("errorMessage", "We couldn't find that private room. Check the code.");
    joinRoom(socket, room, cleanName(d.name));
  });
  socket.on("leave", () => leaveRoom(socket));
  socket.on("p", cb => { if (typeof cb === "function") cb(); });

  // Batched input commands: [{s, l, r, j, f, a}]
  socket.on("c", batch => {
    const room = rooms.get(socket.data.roomCode);
    const p = room && room.players.get(socket.id);
    if (!p || !Array.isArray(batch)) return;
    const now = Date.now();
    if (!socket.data.win || now - socket.data.win > 1000) { socket.data.win = now; socket.data.cnt = 0; }
    for (const c of batch.slice(0, 8)) {
      if (++socket.data.cnt > 130) return;            // ~2x the legit rate
      if (!c || !Number.isInteger(c.s) || c.s <= p.lastSeq) continue;
      const a = Number(c.a);
      p.lastSeq = c.s;
      p.q.push({ s: c.s, l: c.l ? 1 : 0, r: c.r ? 1 : 0, j: c.j ? 1 : 0, f: c.f ? 1 : 0, a: Number.isFinite(a) ? a : 0 });
    }
    if (p.q.length > 10) p.q.splice(0, p.q.length - 10);
  });

  socket.on("report", id => {
    if (limited(socket, "report", 2000)) return;
    const room = rooms.get(socket.data.roomCode);
    const target = room && [...room.players.values()].find(p => p.n === id && !p.bot);
    if (target) console.log(`[report] room=${room.code} reported="${target.name}" by="${socket.id}"`);
  });

  socket.on("disconnect", () => leaveRoom(socket));
});

// ---- game loop ----
function botCmd(room, b) {
  let t = null, best = 1e9;
  for (const o of room.players.values()) {
    if (o === b || o.hp <= 0) continue;
    const d = Math.hypot(o.x - b.x, o.y - b.y);
    if (d < best) { best = d; t = o; }
  }
  const c = { l: 0, r: 0, j: 0, f: 0, a: b.a };
  if (!t) return c;
  const ai = b.ai, dx = t.x - b.x, dy = (t.y - 26) - (b.y - 30);
  if (ai.think-- <= 0) { ai.think = 20 + Math.floor(Math.random() * 40); ai.strafe = Math.random() < 0.5 ? -1 : 1; ai.burst = Math.random() < 0.7; }
  const dir = Math.abs(dx) > 380 ? Math.sign(dx) : Math.abs(dx) < 170 ? -Math.sign(dx) : ai.strafe;
  if (dir < 0) c.l = 1; else c.r = 1;
  if ((dy < -60 && Math.random() < 0.08) || Math.random() < 0.006) c.j = 1;
  c.a = Math.atan2(dy, dx) + (Math.random() - 0.5) * 0.4;
  b.a = c.a;
  if (ai.burst && best < 650) c.f = 1;
  return c;
}

function shoot(room, p) {
  const dx = Math.cos(p.a), dy = Math.sin(p.a);
  room.bullets.push({ id: room.nextBullet++, o: p.n, x: p.x + dx * 26, y: p.y - 30 + dy * 26,
    vx: dx * BULLET_SPEED, vy: dy * BULLET_SPEED, life: BULLET_LIFE });
}

function applyCmd(room, p, c) {
  BW.stepPlayer(p, c);
  p.a = c.a;
  if (c.f && room.tick - p.lastShot >= SHOT_COOLDOWN) { p.lastShot = room.tick; shoot(room, p); }
}

function resetForMatch(room) {
  room.bullets = [];
  const taken = [];
  for (const p of room.players.values()) {
    const s = pickSpawn(room, p);
    Object.assign(p, BW.newBody(s.x, s.y), { hp: 100, kills: 0, deaths: 0, prot: PROTECT_TICKS });
    taken.push(s);
  }
}

function setPhase(room, phase, seconds) {
  room.phase = phase;
  room.phaseEnd = room.tick + Math.round(seconds * TICK_RATE);
}

function updatePhase(room) {
  const n = room.players.size;
  if (room.phase === "waiting") { if (n >= 2) { resetForMatch(room); setPhase(room, "countdown", COUNTDOWN_SEC); } }
  else if (room.phase === "countdown") {
    if (n < 2) room.phase = "waiting";
    else if (room.tick >= room.phaseEnd) { setPhase(room, "playing", MATCH_SEC); io.to(room.code).emit("ev", { t: "start" }); }
  } else if (room.phase === "playing") {
    if (room.tick >= room.phaseEnd) {
      setPhase(room, "ended", RESULTS_SEC);
      const top = Math.max(...[...room.players.values()].map(p => p.kills));
      io.to(room.code).emit("ev", { t: "end", win: [...room.players.values()].filter(p => p.kills === top).map(p => p.n) });
    }
  } else if (room.phase === "ended" && room.tick >= room.phaseEnd) {
    if (n >= 2) { resetForMatch(room); setPhase(room, "countdown", COUNTDOWN_SEC); } else room.phase = "waiting";
  }
}

function tickRoom(room) {
  room.tick++;
  updatePhase(room);
  for (const p of room.players.values()) {
    if (p.prot > 0) p.prot--;
    if (p.hp <= 0) {
      p.q.length = 0;
      if (p.q.length === 0 && p.lastSeq) p.ack = p.lastSeq;
      if (room.tick >= p.respawnAt && room.phase !== "ended") {
        const s = pickSpawn(room, p);
        Object.assign(p, BW.newBody(s.x, s.y), { hp: 100, prot: PROTECT_TICKS });
      }
      continue;
    }
    if (p.bot) applyCmd(room, p, botCmd(room, p));
    else {
      let k = p.q.length > 3 ? 2 : 1;
      while (k-- > 0 && p.q.length) { const c = p.q.shift(); p.ack = c.s; applyCmd(room, p, c); }
    }
  }
  for (const b of room.bullets) {
    b.x += b.vx; b.y += b.vy; b.life--;
    if (b.life <= 0 || b.y >= WORLD.ground || b.y < 0 || b.x < 0 || b.x > WORLD.width) { b.dead = true; continue; }
    if (room.phase !== "playing") continue;
    for (const p of room.players.values()) {
      if (p.n === b.o || p.hp <= 0 || p.prot > 0) continue;
      if (Math.hypot(p.x - b.x, (p.y - 26) - b.y) < HIT_R) {
        p.hp -= DMG; b.dead = true;
        io.to(room.code).emit("ev", { t: "hit", x: r1(b.x), y: r1(b.y), v: p.n, by: b.o });
        if (p.hp <= 0) {
          p.hp = 0; p.deaths++; p.respawnAt = room.tick + RESPAWN_TICKS;
          const killer = [...room.players.values()].find(q => q.n === b.o);
          if (killer) killer.kills++;
          io.to(room.code).emit("ev", { t: "kill", k: b.o, v: p.n, x: r1(p.x), y: r1(p.y - 26) });
        }
        break;
      }
    }
  }
  room.bullets = room.bullets.filter(b => !b.dead);
  if (room.tick % 2 === 0) io.to(room.code).emit("s", snapshot(room));
}

function snapshot(room) {
  return {
    ph: room.phase,
    rem: Math.max(0, Math.ceil((room.phaseEnd - room.tick) / TICK_RATE)),
    // [n, x, y, vx, vy, hp, angle, kills, deaths, protected, ack, pj, coyote, air]
    p: [...room.players.values()].map(p => [p.n, r3(p.x), r3(p.y), r3(p.vx), r3(p.vy), p.hp, r3(p.a), p.kills, p.deaths, p.prot > 0 ? 1 : 0, p.ack, p.pj, p.coyote, p.air]),
    b: room.bullets.map(b => [b.id, r1(b.x), r1(b.y), r1(b.vx), r1(b.vy), b.o])
  };
}

let last = Date.now(), acc = 0;
setInterval(() => {
  const now = Date.now();
  acc += Math.min(now - last, 250);
  last = now;
  while (acc >= STEP_MS) { for (const room of rooms.values()) tickRoom(room); acc -= STEP_MS; }
}, 8);

if (require.main === module) {
  server.listen(PORT, "0.0.0.0", () => console.log(`Project BattleWorld v0.2 running on port ${PORT}`));
}
module.exports = { io, rooms };
